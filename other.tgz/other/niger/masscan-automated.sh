#!/bin/bash
set -euo pipefail

usage() {
    echo "Usage: $0 -range <CIDR>"
    exit 1
}

range=""

while [[ $# -gt 0 ]]; do
    case "$1" in
        -range)
            range="$2"
            shift 2
            ;;
        *)
            usage
            ;;
    esac
done

[[ -z "$range" ]] && usage

prefix="${range%%/*}"
prefix="${prefix%.0}"

ports="80,22,445,3389,5900,139,23"
json_file="${prefix}-scan.json"

echo "[*] Scanning $range ..."

sudo masscan -p"$ports" "$range" --rate 1000 -oJ "$json_file"

echo "[*] Parsing results..."

extract_port () {
    local port="$1"
    jq -r --arg port "$port" '
        .[]
        | select(.ports[]?.port == ($port|tonumber) and .ports[]?.status == "open")
        | .ip
    ' "$json_file" | sort -u
}

extract_port 445 > "${prefix}-smb.txt"
extract_port 22  > "${prefix}-ssh.txt"
extract_port 80  > "${prefix}-http.txt"
extract_port 3389 > "${prefix}-rdp.txt"
extract_port 23  > "${prefix}-telnet.txt"
extract_port 139 > "${prefix}-netbios.txt"
extract_port 5900 > "${prefix}-vnc.txt"

echo "[+] Done"
